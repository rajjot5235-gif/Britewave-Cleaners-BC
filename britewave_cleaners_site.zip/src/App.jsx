import React from 'react';

export default function App() {
  return (
    <div style={{ fontFamily: 'Arial, sans-serif', textAlign: 'center', padding: '20px' }}>
      <h1>Britewave Cleaners</h1>
      <h2>Serving the Lower Mainland, BC</h2>
      <p>Professional Residential & Commercial Cleaning Services</p>
      <p>Contact us: info@britewave.ca | (604) 555-0123</p>
    </div>
  );
}